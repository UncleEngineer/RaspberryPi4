from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import csv

def Home(request):

    with open('/home/pi/Desktop/LCD/DHT22-101.csv',newline='',encoding='utf-8') as file:
        fr = csv.reader(file)
        data = list(fr)
        print('IOT-DATA:',data)
        # data.reverse()
        context = {'data':data}

    return render(request,'iot/home.html',context)
    

